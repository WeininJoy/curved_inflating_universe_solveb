************
Moved: Cards
************

.. meta::
    :http-equiv=refresh: 0; ../api/cards.html

This page has been moved to :doc:`../api/cards`.
