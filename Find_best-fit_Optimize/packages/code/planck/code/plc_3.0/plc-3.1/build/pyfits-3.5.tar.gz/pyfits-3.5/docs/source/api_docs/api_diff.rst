**************
Moved: Differs
**************

.. meta::
    :http-equiv=refresh: 0; ../api/diff.html

This page has been moved to :doc:`../api/diff`.
