**********************************************
Moved: File Handling and Convenience Functions
**********************************************

.. meta::
    :http-equiv=refresh: 0; ../api/files.html

This page has been moved to :doc:`../api/files`.
